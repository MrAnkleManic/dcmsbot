"""Pydantic models for UK Parliament API responses."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field


class HansardResult(BaseModel):
    """A debate result from the Hansard search API."""

    title: str
    date: str  # ISO date string from SittingDate
    house: str  # "Commons" or "Lords"
    section: str = ""  # e.g. "Commons Chamber", "Westminster Hall"
    external_id: str = ""  # DebateSectionExtId

    @classmethod
    def from_api(cls, item: dict) -> HansardResult:
        sitting = item.get("SittingDate", "")
        date_str = sitting[:10] if sitting else ""
        return cls(
            title=item.get("Title", ""),
            date=date_str,
            house=item.get("House", ""),
            section=item.get("DebateSection", ""),
            external_id=item.get("DebateSectionExtId", ""),
        )


class WrittenQuestion(BaseModel):
    """A written parliamentary question with optional ministerial answer."""

    id: int
    question_text: str = ""
    answer_text: str | None = None
    date_tabled: str = ""
    date_answered: str | None = None
    answering_body: str = ""
    asking_member_id: int | None = None
    house: str = ""
    uin: str = ""

    @classmethod
    def from_api(cls, item: dict) -> WrittenQuestion:
        v = item.get("value", item)
        tabled = v.get("dateTabled", "")
        answered = v.get("dateAnswered")
        return cls(
            id=v.get("id", 0),
            question_text=v.get("questionText", ""),
            answer_text=v.get("answerText"),
            date_tabled=tabled[:10] if tabled else "",
            date_answered=answered[:10] if answered else None,
            answering_body=v.get("answeringBodyName", ""),
            asking_member_id=v.get("askingMemberId"),
            house=v.get("house", ""),
            uin=v.get("uin", ""),
        )


class Member(BaseModel):
    """A UK Parliament member (MP or Peer)."""

    id: int
    name: str  # nameDisplayAs
    full_title: str = ""  # nameFullTitle
    party: str = ""
    constituency: str = ""  # membershipFrom
    house: int = 1  # 1 = Commons, 2 = Lords
    membership_start: str = ""
    is_active: bool = True

    @classmethod
    def from_api(cls, item: dict) -> Member:
        v = item.get("value", item)
        party_info = v.get("latestParty", {})
        membership = v.get("latestHouseMembership", {})
        status = membership.get("membershipStatus", {})
        start = membership.get("membershipStartDate", "")
        return cls(
            id=v.get("id", 0),
            name=v.get("nameDisplayAs", ""),
            full_title=v.get("nameFullTitle", ""),
            party=party_info.get("name", ""),
            constituency=membership.get("membershipFrom", ""),
            house=membership.get("house", 1),
            membership_start=start[:10] if start else "",
            is_active=status.get("statusIsActive", True),
        )


class Bill(BaseModel):
    """A UK Parliament bill."""

    id: int
    short_title: str = ""
    current_house: str = ""
    current_stage: str = ""
    last_updated: str = ""
    is_act: bool = False
    is_defeated: bool = False

    @classmethod
    def from_api(cls, item: dict) -> Bill:
        stage = item.get("currentStage", {})
        updated = item.get("lastUpdate", "")
        return cls(
            id=item.get("billId", 0),
            short_title=item.get("shortTitle", ""),
            current_house=item.get("currentHouse", ""),
            current_stage=stage.get("description", "") if stage else "",
            last_updated=updated[:10] if updated else "",
            is_act=item.get("isAct", False),
            is_defeated=item.get("isDefeated", False),
        )


class EDM(BaseModel):
    """An Early Day Motion."""

    id: int
    title: str = ""
    motion_text: str = ""
    date_tabled: str = ""
    sponsors_count: int = 0
    uin: int | None = None

    @classmethod
    def from_api(cls, item: dict) -> EDM:
        tabled = item.get("DateTabled", "")
        return cls(
            id=item.get("Id", 0),
            title=item.get("Title", ""),
            motion_text=item.get("MotionText", ""),
            date_tabled=tabled[:10] if tabled else "",
            sponsors_count=item.get("SponsorsCount", 0),
            uin=item.get("UIN"),
        )
