"""Summarise Parliament API results into compact text for briefing injection."""

from __future__ import annotations

from .models import HansardResult, Member, WrittenQuestion


def summarise_hansard_results(results: list[HansardResult], topic: str) -> str:
    """Produce a compact paragraph summarising Hansard debate results.

    Example output:
        'The topic "energy security" appeared in 23 Commons debates in the
        last 90 days. Recent debates include: Energy Security Bill second
        reading (14 Mar, Commons Chamber), PM statement on gas prices
        (8 Mar, Commons Chamber).'
    """
    if not results:
        return f'No recent Hansard debates found for "{topic}".'

    count = len(results)
    houses = set(r.house for r in results)
    house_str = " and ".join(sorted(houses)) if houses else "Parliament"

    # Sort by date descending to get most recent first
    sorted_results = sorted(results, key=lambda r: r.date, reverse=True)

    # Build list of recent debate titles (top 3)
    recent = []
    for r in sorted_results[:3]:
        date_short = _short_date(r.date)
        recent.append(f"{r.title} ({date_short}, {r.section or r.house})")

    summary = f'The topic "{topic}" appeared in {count} {house_str} debate{"s" if count != 1 else ""}'

    if sorted_results[0].date and sorted_results[-1].date:
        first = _short_date(sorted_results[-1].date)
        last = _short_date(sorted_results[0].date)
        summary += f" between {first} and {last}"

    summary += "."

    if recent:
        summary += " Recent debates include: " + "; ".join(recent) + "."

    return summary


def summarise_written_questions(results: list[WrittenQuestion], topic: str) -> str:
    """Produce a compact paragraph summarising written question results.

    Example output:
        '47 written questions on "NHS waiting times" in the period queried.
        Most recent ministerial answer (12 Mar, Department of Health):
        "The government remains committed to the 18-week RTT standard..."'
    """
    if not results:
        return f'No written questions found for "{topic}".'

    count = len(results)

    # Find most recent answered question
    answered = [q for q in results if q.answer_text and q.date_answered]
    answered.sort(key=lambda q: q.date_answered or "", reverse=True)

    summary = f'{count} written question{"s" if count != 1 else ""} on "{topic}" in the period queried.'

    if answered:
        latest = answered[0]
        date_short = _short_date(latest.date_answered or "")
        body = latest.answering_body or "unknown department"

        # Truncate answer to first ~120 chars at a word boundary
        answer_snippet = _truncate(latest.answer_text or "", 120)
        summary += f' Most recent ministerial answer ({date_short}, {body}): "{answer_snippet}"'

    return summary


def format_member(member: Member) -> str:
    """Format a Member into a single descriptive line.

    Example output:
        'Sir Keir Starmer: Labour MP for Holborn and St Pancras since 2015.'
    """
    house_label = "MP" if member.house == 1 else "Peer"
    parts = [member.name or member.full_title]

    role_parts = []
    if member.party:
        role_parts.append(member.party)
    role_parts.append(house_label)
    if member.constituency:
        role_parts.append(f"for {member.constituency}")
    if member.membership_start:
        year = member.membership_start[:4]
        role_parts.append(f"since {year}")

    if role_parts:
        parts.append(": " + " ".join(role_parts))

    return "".join(parts) + "."


def _short_date(iso_date: str) -> str:
    """Convert '2026-03-14' to '14 Mar 2026'."""
    if not iso_date or len(iso_date) < 10:
        return iso_date
    months = [
        "", "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
    ]
    try:
        parts = iso_date[:10].split("-")
        year, month, day = parts[0], int(parts[1]), parts[2].lstrip("0") or "0"
        return f"{day} {months[month]} {year}"
    except (IndexError, ValueError):
        return iso_date


def _truncate(text: str, max_len: int) -> str:
    """Truncate text at a word boundary, adding ellipsis if needed."""
    # Strip HTML tags (written answers often contain HTML)
    import re
    clean = re.sub(r"<[^>]+>", " ", text)
    clean = re.sub(r"\s+", " ", clean).strip()

    if len(clean) <= max_len:
        return clean
    truncated = clean[:max_len].rsplit(" ", 1)[0]
    return truncated + "..."
