"""UK Parliament API client with caching, timeouts, and graceful degradation."""

from __future__ import annotations

import logging
import time
from typing import Literal

import httpx

from .models import Bill, EDM, HansardResult, Member, WrittenQuestion

logger = logging.getLogger(__name__)

_USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)

# Cache: (cache_key) -> (timestamp, data)
_cache: dict[str, tuple[float, object]] = {}
_CACHE_TTL = 3600  # 1 hour


def _cache_get(key: str) -> object | None:
    entry = _cache.get(key)
    if entry is None:
        return None
    ts, data = entry
    if time.time() - ts > _CACHE_TTL:
        del _cache[key]
        return None
    return data


def _cache_set(key: str, data: object) -> None:
    _cache[key] = (time.time(), data)


class ParliamentClient:
    """Client for the UK Parliament public APIs.

    Parameters
    ----------
    mode : "standard" or "max"
        "standard" (default) enforces result caps and tight timeouts.
        "max" is accepted but behaves identically for now (future phase).
    """

    def __init__(self, mode: Literal["standard", "max"] = "standard"):
        self.mode = mode
        self._client = httpx.Client(
            timeout=httpx.Timeout(20.0, connect=5.0, read=15.0, pool=5.0),
            headers={"User-Agent": _USER_AGENT},
            follow_redirects=True,
        )

    def search_hansard(
        self,
        query: str,
        date_from: str,
        date_to: str,
        house: str = "Commons",
        max_results: int = 10,
    ) -> list[HansardResult]:
        """Search Hansard debates by keyword and date range."""
        cache_key = f"hansard:{query}:{date_from}:{date_to}:{house}:{max_results}"
        cached = _cache_get(cache_key)
        if cached is not None:
            return cached  # type: ignore[return-value]

        params: dict[str, str | int] = {
            "searchTerm": query,
            "take": min(max_results, 10) if self.mode == "standard" else max_results,
        }
        if house and house != "Both":
            params["house"] = house

        # Hansard API doesn't support date filtering in search params directly,
        # so we filter results post-fetch
        try:
            resp = self._client.get(
                "https://hansard-api.parliament.uk/search/debates.json",
                params=params,
            )
            resp.raise_for_status()
            data = resp.json()
        except (httpx.HTTPError, ValueError) as e:
            logger.warning("Hansard API error: %s", e)
            return []

        results = []
        for item in data.get("Results", []):
            result = HansardResult.from_api(item)
            # Filter by date range
            if date_from and result.date < date_from:
                continue
            if date_to and result.date > date_to:
                continue
            results.append(result)

        _cache_set(cache_key, results)
        return results

    def get_written_questions(
        self,
        topic: str,
        date_from: str,
        date_to: str,
        max_results: int = 20,
    ) -> list[WrittenQuestion]:
        """Search written parliamentary questions by topic and date range."""
        cache_key = f"wq:{topic}:{date_from}:{date_to}:{max_results}"
        cached = _cache_get(cache_key)
        if cached is not None:
            return cached  # type: ignore[return-value]

        params: dict[str, str | int] = {
            "SearchTerm": topic,
            "take": min(max_results, 20) if self.mode == "standard" else max_results,
        }
        if date_from:
            params["TabledWhenFrom"] = date_from
        if date_to:
            params["TabledWhenTo"] = date_to
        params["Answered"] = "Any"

        try:
            resp = self._client.get(
                "https://questions-statements-api.parliament.uk/api/WrittenQuestions/Questions",
                params=params,
            )
            resp.raise_for_status()
            data = resp.json()
        except (httpx.HTTPError, ValueError) as e:
            logger.warning("Written Questions API error: %s", e)
            return []

        results = [
            WrittenQuestion.from_api(item)
            for item in data.get("results", [])
        ]

        _cache_set(cache_key, results)
        return results

    def get_member(self, name: str) -> Member | None:
        """Look up a parliament member by name (fuzzy match). Returns first match."""
        cache_key = f"member:{name}"
        cached = _cache_get(cache_key)
        if cached is not None:
            return cached  # type: ignore[return-value]

        try:
            resp = self._client.get(
                "https://members-api.parliament.uk/api/Members/Search",
                params={"Name": name, "take": 1},
            )
            resp.raise_for_status()
            data = resp.json()
        except (httpx.HTTPError, ValueError) as e:
            logger.warning("Members API error: %s", e)
            return None

        items = data.get("items", [])
        if not items:
            return None

        member = Member.from_api(items[0])
        _cache_set(cache_key, member)
        return member

    def get_bill_status(self, keyword: str) -> list[Bill]:
        """Search bills by keyword."""
        cache_key = f"bill:{keyword}"
        cached = _cache_get(cache_key)
        if cached is not None:
            return cached  # type: ignore[return-value]

        try:
            resp = self._client.get(
                "https://bills-api.parliament.uk/api/v1/Bills",
                params={"SearchTerm": keyword, "take": 5},
            )
            resp.raise_for_status()
            data = resp.json()
        except (httpx.HTTPError, ValueError) as e:
            logger.warning("Bills API error: %s", e)
            return []

        results = [Bill.from_api(item) for item in data.get("items", [])]

        _cache_set(cache_key, results)
        return results

    def get_edms(
        self,
        topic: str,
        min_signatures: int = 10,
        max_results: int = 10,
    ) -> list[EDM]:
        """Search Early Day Motions by topic."""
        cache_key = f"edm:{topic}:{min_signatures}:{max_results}"
        cached = _cache_get(cache_key)
        if cached is not None:
            return cached  # type: ignore[return-value]

        params: dict[str, str | int] = {
            "parameters.searchTerm": topic,
            "parameters.take": min(max_results, 10) if self.mode == "standard" else max_results,
        }

        try:
            resp = self._client.get(
                "https://oralquestionsandmotions-api.parliament.uk/EarlyDayMotions/list",
                params=params,
            )
            resp.raise_for_status()
            data = resp.json()
        except (httpx.HTTPError, ValueError) as e:
            logger.warning("EDM API error: %s", e)
            return []

        results = []
        for item in data.get("Response", []):
            edm = EDM.from_api(item)
            if edm.sponsors_count >= min_signatures:
                results.append(edm)

        _cache_set(cache_key, results)
        return results

    def close(self) -> None:
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
