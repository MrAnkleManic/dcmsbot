"""Historic Hansard client for api.parliament.uk/historic-hansard.

Coverage: 1803-2005. Fetches sitting listings (JSON) and debate
section content (HTML), then extracts individual speaker contributions
using BeautifulSoup.

The client is persona-agnostic — it fetches any parliamentarian's
contributions by speaker URL slug. Persona-specific curation (which
debates to search) lives in the consuming application.
"""

from __future__ import annotations

import logging
import re
import time
from pathlib import Path

import httpx
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

BASE_URL = "https://api.parliament.uk/historic-hansard"

_USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)

# File-based cache for historic content (never changes).
# Set by the consuming application; None = no caching.
_file_cache_dir: Path | None = None


def set_cache_dir(path: str | Path) -> None:
    """Set the directory for permanent file-based caching of historic content."""
    global _file_cache_dir
    _file_cache_dir = Path(path)
    _file_cache_dir.mkdir(parents=True, exist_ok=True)


def _cache_path(house: str, date: str, slug: str, suffix: str) -> Path | None:
    if _file_cache_dir is None:
        return None
    # date like "1982/apr/14" -> "1982-apr-14"
    safe_date = date.replace("/", "-")
    return _file_cache_dir / f"{house}_{safe_date}_{slug}.{suffix}"


def _read_cache(house: str, date: str, slug: str, suffix: str) -> str | None:
    path = _cache_path(house, date, slug, suffix)
    if path and path.exists():
        return path.read_text(encoding="utf-8")
    return None


def _write_cache(house: str, date: str, slug: str, suffix: str, content: str) -> None:
    path = _cache_path(house, date, slug, suffix)
    if path:
        path.write_text(content, encoding="utf-8")


class HistoricHansardClient:
    """Client for api.parliament.uk/historic-hansard."""

    def __init__(self) -> None:
        self._client = httpx.Client(
            timeout=httpx.Timeout(30.0, connect=5.0, read=25.0, pool=5.0),
            headers={"User-Agent": _USER_AGENT},
            follow_redirects=True,
        )

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self._client.close()

    def close(self) -> None:
        self._client.close()

    # ------------------------------------------------------------------
    # Sitting listing (JSON)
    # ------------------------------------------------------------------

    def get_sitting(self, house: str, date: str) -> dict:
        """Get sections for a sitting day.

        Parameters
        ----------
        house : str
            "commons" or "lords"
        date : str
            Date in YYYY/mon/DD format, e.g. "1982/apr/14"

        Returns
        -------
        dict with keys: date_text, volume_id, start_column, end_column,
        sections (list of {slug, title, start_column, end_column, date}).
        Empty dict on error.
        """
        cached = _read_cache(house, date, "sitting", "json")
        if cached:
            import json
            try:
                return json.loads(cached)
            except Exception:
                pass

        url = f"{BASE_URL}/{house}/{date}.js"
        try:
            resp = self._client.get(url)
            resp.raise_for_status()
            data = resp.json()
        except (httpx.HTTPError, ValueError) as exc:
            logger.warning("Historic Hansard sitting fetch failed (%s/%s): %s", house, date, exc)
            return {}

        # Parse the nested structure
        if not data or not isinstance(data, list):
            return {}

        sitting_key = f"house_of_{house}_sitting"
        sitting = data[0].get(sitting_key, {})
        if not sitting:
            return {}

        sections = []
        for item in sitting.get("top_level_sections", []):
            sec = item.get("section", {})
            sections.append({
                "slug": sec.get("slug", ""),
                "title": sec.get("title", ""),
                "start_column": sec.get("start_column", ""),
                "end_column": sec.get("end_column", ""),
                "date": sec.get("date", ""),
            })

        result = {
            "date_text": sitting.get("date_text", ""),
            "volume_id": sitting.get("volume_id"),
            "start_column": sitting.get("start_column", ""),
            "end_column": sitting.get("end_column", ""),
            "sections": sections,
        }

        # Cache permanently
        import json
        _write_cache(house, date, "sitting", "json", json.dumps(result))
        return result

    # ------------------------------------------------------------------
    # Section HTML
    # ------------------------------------------------------------------

    def get_section_html(self, house: str, date: str, slug: str) -> str:
        """Get full HTML of a debate section.

        Parameters
        ----------
        house : str
            "commons" or "lords"
        date : str
            Date in YYYY/mon/DD format
        slug : str
            Section slug, e.g. "falkland-islands"

        Returns
        -------
        HTML string, or empty string on error.
        """
        cached = _read_cache(house, date, slug, "html")
        if cached:
            return cached

        url = f"{BASE_URL}/{house}/{date}/{slug}"
        try:
            resp = self._client.get(url)
            resp.raise_for_status()
            html = resp.text
        except httpx.HTTPError as exc:
            logger.warning("Historic Hansard section fetch failed (%s/%s/%s): %s",
                           house, date, slug, exc)
            return ""

        _write_cache(house, date, slug, "html", html)
        return html

    # ------------------------------------------------------------------
    # Contribution extraction
    # ------------------------------------------------------------------

    def extract_contributions(
        self,
        html: str,
        speaker: str = "mrs-margaret-thatcher",
    ) -> list[dict]:
        """Parse HTML to extract a specific speaker's contributions.

        Parameters
        ----------
        html : str
            Full section HTML from get_section_html().
        speaker : str
            Speaker URL slug (appears in cite href), e.g.
            "mrs-margaret-thatcher", "mr-tony-blair".

        Returns
        -------
        List of dicts: {text, column, speech_id, speaker_title, section_cite}
        """
        if not html:
            return []

        soup = BeautifulSoup(html, "html.parser")

        # Extract section citation (e.g. "HC Deb 03 April 1982 vol 21 cc633-68")
        section_cite_el = soup.find("cite", class_="section")
        section_cite = section_cite_el.get_text(strip=True) if section_cite_el else ""

        # Extract page title for section title
        title_el = soup.find("h1", class_="title")
        section_title = title_el.get_text(strip=True) if title_el else ""

        contributions = []
        for div in soup.find_all("div", class_="member_contribution"):
            blockquote = div.find("blockquote", class_="contribution_text")
            if not blockquote:
                continue

            # Check if this is our speaker
            cite_attr = blockquote.get("cite", "")
            if speaker not in cite_attr:
                continue

            # Get speaker title (e.g. "The Prime Minister (Mrs. Margaret Thatcher)")
            cite_el = blockquote.find("cite", class_="member")
            speaker_title = cite_el.get_text(strip=True) if cite_el else ""

            # Get speech ID
            speech_id = div.get("id", "")

            # Extract column number from the contribution ID
            # Format: S6CV0021P0-02553 → column from nearest preceding column_permalink
            column = self._extract_column(div, soup)

            # Get speech text (all <p> tags, excluding the cite)
            paragraphs = []
            for p in blockquote.find_all("p"):
                # Clean up the text: remove column permalink anchors
                text = p.get_text(separator=" ", strip=True)
                # Remove column numbers that appear inline
                text = re.sub(r"\s*\d{3,5}\s*$", "", text)
                text = text.strip()
                if text:
                    paragraphs.append(text)

            if not paragraphs:
                continue

            contributions.append({
                "text": "\n\n".join(paragraphs),
                "column": column,
                "speech_id": speech_id,
                "speaker_title": speaker_title,
                "section_title": section_title,
                "section_cite": section_cite,
            })

        return contributions

    @staticmethod
    def _extract_column(contribution_div, soup) -> str:
        """Extract the column number for a contribution.

        Looks for the nearest preceding column_permalink anchor.
        """
        from bs4 import Tag

        for prev in contribution_div.previous_siblings:
            if not isinstance(prev, Tag):
                continue

            # Direct column-permalink anchor
            if "column-permalink" in (prev.get("class") or []):
                col_id = prev.get("id", "")
                if col_id.startswith("column_"):
                    return col_id.replace("column_", "")

            # Column-permalink nested inside another element
            col_link = prev.find("a", class_="column-permalink")
            if col_link and col_link.get("id", "").startswith("column_"):
                return col_link["id"].replace("column_", "")

        # Also check inside the contribution div itself for inline column markers
        from bs4 import Tag as _  # noqa
        for col in contribution_div.find_all("a", class_="column-permalink"):
            col_id = col.get("id", "")
            if col_id.startswith("column_"):
                return col_id.replace("column_", "")

        return ""

    # ------------------------------------------------------------------
    # Multi-date search
    # ------------------------------------------------------------------

    def search_by_debates(
        self,
        house: str,
        debates: list[dict],
        speaker: str = "mrs-margaret-thatcher",
    ) -> list[dict]:
        """Fetch contributions across a list of curated debates.

        Parameters
        ----------
        house : str
            "commons" or "lords"
        debates : list[dict]
            Each dict must have "date" and "slug" keys.
            Optional: "title", "context".
        speaker : str
            Speaker URL slug.

        Returns
        -------
        Flattened list of contribution dicts, each augmented with
        "date", "slug", "debate_title", and "debate_context".
        """
        all_contributions = []
        for debate in debates:
            date = debate["date"]
            slug = debate["slug"]
            html = self.get_section_html(house, date, slug)
            if not html:
                continue

            contribs = self.extract_contributions(html, speaker)
            for c in contribs:
                c["date"] = date
                c["slug"] = slug
                c["debate_title"] = debate.get("title", c.get("section_title", ""))
                c["debate_context"] = debate.get("context", "")
            all_contributions.extend(contribs)

        return all_contributions

    def get_contribution_url(self, house: str, date: str, slug: str, speech_id: str = "") -> str:
        """Build a direct URL to a debate section (or specific speech)."""
        url = f"{BASE_URL}/{house}/{date}/{slug}"
        if speech_id:
            url += f"#{speech_id}"
        return url
