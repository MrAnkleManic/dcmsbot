"""Stance detection for parliamentary text using DeBERTa-v3-MNLI.

FinBERT measures sentiment (positive/negative/neutral) which reads
the *register* of text — parliamentary formal language always reads
neutral. DeBERTa-v3-MNLI does zero-shot classification via NLI,
detecting whether text is supportive, critical, or neutral *toward
a specific topic*. This captures actual stance, not register.

Example: "The minister's response is wholly inadequate" reads as
neutral sentiment to FinBERT (formal register) but as clearly
CRITICAL stance to DeBERTa.

FinBERT remains available for non-parliamentary text (news, market
commentary) where natural sentiment is the correct signal.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone

from ..parliament.models import HansardResult
from .models import StanceSignal

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# DeBERTa pipeline (lazy-loaded singleton)
# ---------------------------------------------------------------------------

_deberta_pipeline = None
_deberta_available: bool | None = None  # None = not yet tried

STANCE_LABELS = ["supportive", "critical", "neutral"]


def _get_deberta():
    """Return the DeBERTa zero-shot classification pipeline, loading on first call.

    Uses CPU (MPS has compatibility issues with some NLI models).
    Returns None if DeBERTa cannot be loaded.
    """
    global _deberta_pipeline, _deberta_available

    if _deberta_available is False:
        return None
    if _deberta_pipeline is not None:
        return _deberta_pipeline

    try:
        from transformers import pipeline as hf_pipeline

        _deberta_pipeline = hf_pipeline(
            "zero-shot-classification",
            model="MoritzLaurer/DeBERTa-v3-base-mnli-fever-anli",
            device="cpu",  # CPU is safest for NLI models
        )
        _deberta_available = True
        logger.info("DeBERTa-v3-MNLI loaded on CPU")
        return _deberta_pipeline

    except Exception as e:
        logger.warning("DeBERTa unavailable: %s", e)
        _deberta_available = False
        return None


# ---------------------------------------------------------------------------
# Stance classification
# ---------------------------------------------------------------------------


def classify_stance(text: str, topic: str) -> dict:
    """Classify a single text's stance toward a topic.

    Returns:
        {"label": "supportive"|"critical"|"neutral",
         "scores": {"supportive": 0.12, "critical": 0.75, "neutral": 0.13}}
    """
    pipe = _get_deberta()
    if pipe is None:
        raise RuntimeError("DeBERTa not available")

    result = pipe(
        text,
        candidate_labels=STANCE_LABELS,
        hypothesis_template=f"This speech is {{}} of {topic}.",
    )
    return {
        "label": result["labels"][0],
        "scores": dict(zip(result["labels"], result["scores"])),
    }


def _classify_batch(texts: list[str], topic: str) -> list[dict]:
    """Classify stance for a batch of texts.

    Returns list of {"label": str, "scores": dict} in same order as input.
    """
    pipe = _get_deberta()
    if pipe is None:
        raise RuntimeError("DeBERTa not available")

    results = []
    for text in texts:
        r = pipe(
            text,
            candidate_labels=STANCE_LABELS,
            hypothesis_template=f"This speech is {{}} of {topic}.",
        )
        results.append({
            "label": r["labels"][0],
            "scores": dict(zip(r["labels"], r["scores"])),
        })
    return results


# ---------------------------------------------------------------------------
# Public API — Hansard stance scoring
# ---------------------------------------------------------------------------


def score_hansard_stance(
    results: list[HansardResult],
    topic: str,
) -> StanceSignal:
    """Score the stance of Hansard debate titles toward a topic.

    Uses DeBERTa-v3-MNLI zero-shot classification. Unlike FinBERT
    sentiment, this detects whether speeches are supportive, critical,
    or neutral *toward the specific topic*, not the emotional valence
    of the text.
    """
    if not results:
        return StanceSignal(
            topic=topic,
            sample_size=0,
            supportive=0,
            critical=0,
            neutral=0,
            dominant_stance="neutral",
            recent_trend="stable",
            summary=f"No debates found on '{topic}' to analyse stance.",
        )

    # Collect texts and dates
    texts = []
    dates = []
    for r in results:
        if r.title:
            texts.append(r.title)
            dates.append(r.date)

    if not texts:
        return StanceSignal(
            topic=topic,
            sample_size=0,
            supportive=0,
            critical=0,
            neutral=0,
            dominant_stance="neutral",
            recent_trend="stable",
            summary=f"No scoreable text found on '{topic}'.",
        )

    stances = _classify_batch(texts, topic)

    # Count stances
    counts = {"supportive": 0, "critical": 0, "neutral": 0}
    dated_stances = []
    for stance, date in zip(stances, dates):
        counts[stance["label"]] += 1
        dated_stances.append({"date": date, "label": stance["label"]})

    total = len(stances)
    dominant = max(counts, key=counts.get)
    trend = _stance_trend(dated_stances)

    summary = (
        f"Parliamentary stance on '{topic}': "
        f"{counts['critical']} critical, {counts['supportive']} supportive, "
        f"{counts['neutral']} neutral across {total} debates. "
        f"Trend: {trend} over the last 30 days."
    )

    return StanceSignal(
        topic=topic,
        sample_size=total,
        supportive=counts["supportive"],
        critical=counts["critical"],
        neutral=counts["neutral"],
        dominant_stance=dominant,
        recent_trend=trend,
        summary=summary,
    )


def _stance_trend(dated_stances: list[dict]) -> str:
    """Compare stance distribution of last 30 days vs prior 30 days.

    Returns "increasingly critical", "increasingly supportive", or "stable".
    """
    now = datetime.now(timezone.utc)
    cutoff = now - timedelta(days=30)

    recent_critical = 0
    recent_total = 0
    older_critical = 0
    older_total = 0

    for s in dated_stances:
        if not s["date"]:
            continue
        try:
            d = datetime.strptime(s["date"], "%Y-%m-%d").replace(tzinfo=timezone.utc)
        except ValueError:
            continue
        if d >= cutoff:
            recent_total += 1
            if s["label"] == "critical":
                recent_critical += 1
        else:
            older_total += 1
            if s["label"] == "critical":
                older_critical += 1

    if not recent_total or not older_total:
        return "stable"

    recent_rate = recent_critical / recent_total
    older_rate = older_critical / older_total
    diff = recent_rate - older_rate

    if diff > 0.15:
        return "increasingly critical"
    elif diff < -0.15:
        return "increasingly supportive"
    return "stable"
