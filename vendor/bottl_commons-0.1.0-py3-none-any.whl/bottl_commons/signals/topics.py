"""BERTopic-based topic discovery over Hansard debate texts.

Supplements the debate-counting in topic_tracker.py by clustering
retrieved debates into discovered topics with trend analysis.
"""

from __future__ import annotations

import logging
from collections import Counter
from datetime import datetime, timedelta, timezone

from ..parliament.models import HansardResult
from .models import TopicAnalysis, TopicInfo

logger = logging.getLogger(__name__)

# Minimum documents for BERTopic to produce meaningful clusters
_MIN_DOCUMENTS = 10

# ---------------------------------------------------------------------------
# Embedding model (lazy-loaded singleton)
# ---------------------------------------------------------------------------

_embedding_model = None
_embedding_available: bool | None = None


def _get_embedding_model():
    """Return the MiniLM sentence-transformer, loading on first call."""
    global _embedding_model, _embedding_available

    if _embedding_available is False:
        return None
    if _embedding_model is not None:
        return _embedding_model

    try:
        from sentence_transformers import SentenceTransformer
        import torch

        device = "mps" if torch.backends.mps.is_available() else "cpu"
        try:
            _embedding_model = SentenceTransformer(
                "all-MiniLM-L6-v2", device=device,
            )
        except Exception:
            if device == "mps":
                logger.info("MiniLM MPS failed, falling back to CPU")
                _embedding_model = SentenceTransformer(
                    "all-MiniLM-L6-v2", device="cpu",
                )
            else:
                raise

        _embedding_available = True
        logger.info("MiniLM embedding model loaded on %s", device)
        return _embedding_model

    except Exception as e:
        logger.warning("Embedding model unavailable: %s", e)
        _embedding_available = False
        return None


# ---------------------------------------------------------------------------
# Topic analysis
# ---------------------------------------------------------------------------


def analyse_debate_topics(
    results: list[HansardResult],
    n_topics: int = 5,
) -> TopicAnalysis:
    """Run BERTopic over retrieved Hansard debate texts.

    Discovers topic clusters in the retrieved debates and determines
    whether each topic is growing, stable, or declining based on
    the date distribution of debates in that cluster.

    Returns an empty TopicAnalysis if fewer than _MIN_DOCUMENTS
    texts are available or if BERTopic fails.
    """
    empty = TopicAnalysis(topics=[], total_documents=len(results))

    if len(results) < _MIN_DOCUMENTS:
        return empty

    # Collect texts and dates
    texts = []
    dates = []
    titles = []
    for r in results:
        if r.title:
            texts.append(r.title)
            dates.append(r.date)
            titles.append(r.title)

    if len(texts) < _MIN_DOCUMENTS:
        return empty

    embedding_model = _get_embedding_model()
    if embedding_model is None:
        return empty

    try:
        from bertopic import BERTopic
        from sklearn.cluster import AgglomerativeClustering

        # Clamp n_topics to what the data can support
        # AgglomerativeClustering needs n_clusters <= n_samples
        effective_topics = min(n_topics, len(texts) // 3, len(texts))
        if effective_topics < 2:
            return empty

        cluster_model = AgglomerativeClustering(n_clusters=effective_topics)

        topic_model = BERTopic(
            embedding_model=embedding_model,
            hdbscan_model=cluster_model,
            nr_topics=effective_topics,
            verbose=False,
        )

        topic_ids, _probs = topic_model.fit_transform(texts)

        # Build topic info from BERTopic results
        topic_infos = []
        topic_info_dict = topic_model.get_topic_info()

        for _, row in topic_infos_iter(topic_info_dict, topic_ids, texts, titles, dates):
            topic_infos.append(row)

        return TopicAnalysis(
            topics=topic_infos,
            total_documents=len(texts),
        )

    except Exception as e:
        logger.warning("BERTopic analysis failed: %s", e)
        return empty


def topic_infos_iter(topic_info_df, topic_ids, texts, titles, dates):
    """Extract TopicInfo objects from BERTopic results."""
    now = datetime.now(timezone.utc)
    midpoint = now - timedelta(days=45)

    # Group documents by topic
    topic_docs: dict[int, list[int]] = {}
    for idx, tid in enumerate(topic_ids):
        if tid == -1:  # outlier topic
            continue
        topic_docs.setdefault(tid, []).append(idx)

    for tid, doc_indices in sorted(topic_docs.items()):
        # Get keywords from BERTopic
        try:
            topic_words = topic_info_df[
                topic_info_df["Topic"] == tid
            ]["Representation"].iloc[0]
            if isinstance(topic_words, str):
                keywords = [w.strip() for w in topic_words.split(",")][:5]
            elif isinstance(topic_words, list):
                keywords = [str(w) for w in topic_words[:5]]
            else:
                keywords = []
        except (IndexError, KeyError):
            keywords = []

        label = ", ".join(keywords[:3]) if keywords else f"Topic {tid}"

        # Representative debates (up to 3 titles)
        rep_debates = [titles[i] for i in doc_indices[:3]]

        # Trend: compare dates before/after midpoint
        recent_count = 0
        older_count = 0
        for i in doc_indices:
            try:
                d = datetime.strptime(dates[i], "%Y-%m-%d").replace(
                    tzinfo=timezone.utc
                )
                if d >= midpoint:
                    recent_count += 1
                else:
                    older_count += 1
            except (ValueError, IndexError):
                continue

        if recent_count > older_count + 1:
            trend = "growing"
        elif older_count > recent_count + 1:
            trend = "declining"
        else:
            trend = "stable"

        info = TopicInfo(
            id=tid,
            label=label,
            keywords=keywords,
            count=len(doc_indices),
            representative_debates=rep_debates,
            trend=trend,
        )
        yield tid, info
