"""Political signal extraction: topic salience, sentiment analysis, stance detection, and topic discovery."""

from .models import SentimentSignal, StanceSignal, TopicAnalysis, TopicInfo, TopicSalience
from .sentiment import score_hansard_sentiment, score_written_questions_sentiment
from .stance import score_hansard_stance
from .topic_tracker import get_topic_salience
from .topics import analyse_debate_topics

__all__ = [
    "TopicSalience",
    "SentimentSignal",
    "StanceSignal",
    "get_topic_salience",
    "score_hansard_sentiment",
    "score_written_questions_sentiment",
    "score_hansard_stance",
    "analyse_debate_topics",
]
