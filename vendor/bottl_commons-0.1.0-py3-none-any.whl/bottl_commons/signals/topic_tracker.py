"""Parliamentary salience tracking — debate counting over time.

Converts Hansard search results into a forecastable time series
by bucketing debate mentions per week (or day).
"""

from __future__ import annotations

import logging
from collections import defaultdict
from datetime import datetime, timedelta, timezone

from ..parliament import ParliamentClient
from .models import TopicSalience

logger = logging.getLogger(__name__)


def get_topic_salience(
    topic: str,
    days_back: int = 180,
    granularity: str = "weekly",
    client: ParliamentClient | None = None,
    prefetched_results: list | None = None,
) -> TopicSalience:
    """Fetch Hansard debates mentioning a topic and build a salience time series.

    Parameters
    ----------
    topic : str
        Search term for Hansard (e.g. "Starmer", "energy security").
    days_back : int
        How far back to search (default 180 days).
    granularity : str
        "weekly" or "daily" bucketing.
    client : ParliamentClient, optional
        Reuse an existing client. If None, creates one internally.
    prefetched_results : list[HansardResult], optional
        If provided, skip the API call and bucket these results directly.
        Use this when Hansard results have already been fetched by the
        parliament bridge, avoiding duplicate API calls and ensuring
        consistency with the Parliamentary Sources panel.

    Returns
    -------
    TopicSalience
        Time series of debate counts per bucket, with trend analysis.
    """
    now = datetime.now(timezone.utc)

    if prefetched_results is not None:
        results = prefetched_results
    else:
        date_from = (now - timedelta(days=days_back)).strftime("%Y-%m-%d")
        date_to = now.strftime("%Y-%m-%d")

        # Fetch debates
        owns_client = client is None
        if owns_client:
            client = ParliamentClient(mode="standard")

        try:
            results = client.search_hansard(
                query=topic,
                date_from=date_from,
                date_to=date_to,
                house="Both",
                max_results=50,  # get more results for time series
            )
        except Exception as e:
            logger.warning("Hansard fetch failed for salience on %r: %s", topic, e)
            results = []
        finally:
            if owns_client:
                client.close()

    # Bucket by time period
    bucket_counts: dict[str, int] = defaultdict(int)

    if granularity == "daily":
        # Generate all day buckets
        start = now - timedelta(days=days_back)
        for i in range(days_back + 1):
            d = start + timedelta(days=i)
            bucket_counts[d.strftime("%Y-%m-%d")] = 0
    else:
        # Weekly: generate Monday-start buckets
        start = now - timedelta(days=days_back)
        # Align to Monday
        start = start - timedelta(days=start.weekday())
        d = start
        while d <= now:
            bucket_counts[d.strftime("%Y-%m-%d")] = 0
            d += timedelta(weeks=1)

    # Count debates per bucket
    for r in results:
        if not r.date:
            continue
        try:
            debate_date = datetime.strptime(r.date, "%Y-%m-%d")
        except ValueError:
            continue

        if granularity == "daily":
            key = r.date
        else:
            # Find Monday of the week
            monday = debate_date - timedelta(days=debate_date.weekday())
            key = monday.strftime("%Y-%m-%d")

        if key in bucket_counts:
            bucket_counts[key] += 1

    # Sort by date
    sorted_buckets = sorted(bucket_counts.items())
    dates = [b[0] for b in sorted_buckets]
    values = [float(b[1]) for b in sorted_buckets]
    total_mentions = sum(int(v) for v in values)

    # Compute trend: last 30 days vs prior 30 days
    trend, change_pct, change_desc = _compute_trend(
        dates, values, topic, granularity
    )

    return TopicSalience(
        topic=topic,
        dates=dates,
        values=values,
        total_mentions=total_mentions,
        trend=trend,
        change_pct=change_pct,
        change_description=change_desc,
    )


def _compute_trend(
    dates: list[str],
    values: list[float],
    topic: str,
    granularity: str,
) -> tuple[str, float, str]:
    """Compare last 30 days to prior 30 days for trend detection."""
    now = datetime.now(timezone.utc)
    cutoff_recent = now - timedelta(days=30)
    cutoff_prior = now - timedelta(days=60)

    recent_total = 0.0
    prior_total = 0.0

    for date_str, val in zip(dates, values):
        try:
            d = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        except ValueError:
            continue

        if d >= cutoff_recent:
            recent_total += val
        elif d >= cutoff_prior:
            prior_total += val

    # Compute percentage change
    if prior_total > 0:
        change_pct = round((recent_total - prior_total) / prior_total * 100, 1)
    elif recent_total > 0:
        change_pct = 100.0  # went from 0 to something
    else:
        change_pct = 0.0

    # Classify trend
    if change_pct > 15:
        trend = "rising"
    elif change_pct < -15:
        trend = "falling"
    else:
        trend = "stable"

    # Human-readable description
    period_label = "30 days"
    if trend == "rising":
        change_desc = (
            f"Parliamentary attention to '{topic}' has increased "
            f"{abs(change_pct):.0f}% in the last {period_label} "
            f"compared to the prior period "
            f"({int(recent_total)} mentions vs {int(prior_total)} previously)."
        )
    elif trend == "falling":
        change_desc = (
            f"Parliamentary attention to '{topic}' has decreased "
            f"{abs(change_pct):.0f}% in the last {period_label} "
            f"compared to the prior period "
            f"({int(recent_total)} mentions vs {int(prior_total)} previously)."
        )
    else:
        change_desc = (
            f"Parliamentary attention to '{topic}' is broadly stable "
            f"({int(recent_total)} mentions in the last {period_label} "
            f"vs {int(prior_total)} previously)."
        )

    return trend, change_pct, change_desc
