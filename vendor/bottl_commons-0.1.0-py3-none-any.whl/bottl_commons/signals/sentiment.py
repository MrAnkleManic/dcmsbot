"""Sentiment analysis for parliamentary text using FinBERT.

FinBERT (ProsusAI/FinBERT) is fine-tuned on financial text, which is
closer to formal parliamentary register than VADER's social-media
calibration. VADER is kept as a fallback if FinBERT fails to load.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone

from ..parliament.models import HansardResult, WrittenQuestion
from .models import SentimentSignal

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# FinBERT pipeline (lazy-loaded singleton)
# ---------------------------------------------------------------------------

_finbert_pipeline = None
_finbert_available: bool | None = None  # None = not yet tried


def _get_finbert():
    """Return the FinBERT sentiment pipeline, loading on first call.

    Uses MPS (Apple Silicon GPU) if available, falls back to CPU.
    Returns None if FinBERT cannot be loaded.
    """
    global _finbert_pipeline, _finbert_available

    if _finbert_available is False:
        return None
    if _finbert_pipeline is not None:
        return _finbert_pipeline

    try:
        from transformers import pipeline as hf_pipeline
        import torch

        device = "mps" if torch.backends.mps.is_available() else "cpu"
        try:
            _finbert_pipeline = hf_pipeline(
                "sentiment-analysis",
                model="ProsusAI/finbert",
                device=device,
                truncation=True,
                max_length=512,
            )
        except Exception:
            # MPS may fail for some ops — fall back to CPU
            if device == "mps":
                logger.info("FinBERT MPS failed, falling back to CPU")
                _finbert_pipeline = hf_pipeline(
                    "sentiment-analysis",
                    model="ProsusAI/finbert",
                    device="cpu",
                    truncation=True,
                    max_length=512,
                )
            else:
                raise

        _finbert_available = True
        logger.info("FinBERT loaded on %s", device)
        return _finbert_pipeline

    except Exception as e:
        logger.warning("FinBERT unavailable, falling back to VADER: %s", e)
        _finbert_available = False
        return None


# ---------------------------------------------------------------------------
# VADER fallback (lazy-loaded singleton)
# ---------------------------------------------------------------------------

_analyzer = None


def _get_analyzer():
    global _analyzer
    if _analyzer is None:
        from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
        _analyzer = SentimentIntensityAnalyzer()
    return _analyzer


# ---------------------------------------------------------------------------
# Scoring helpers
# ---------------------------------------------------------------------------


def _score_texts_finbert(texts: list[str]) -> list[float]:
    """Score texts with FinBERT, returning compound scores on -1 to +1 scale."""
    pipe = _get_finbert()
    if pipe is None:
        raise RuntimeError("FinBERT not available")

    # FinBERT returns: {"label": "positive"|"negative"|"neutral", "score": float}
    results = pipe(texts, batch_size=16)

    scores = []
    for r in results:
        label = r["label"].lower()
        confidence = r["score"]
        if label == "positive":
            scores.append(confidence)
        elif label == "negative":
            scores.append(-confidence)
        else:  # neutral
            scores.append(0.0)
    return scores


def _score_texts_vader(texts: list[str]) -> list[float]:
    """Score texts with VADER, returning compound scores on -1 to +1 scale."""
    analyzer = _get_analyzer()
    return [analyzer.polarity_scores(t)["compound"] for t in texts]


def _score_texts(texts: list[str]) -> list[float]:
    """Score texts using FinBERT with VADER fallback."""
    try:
        return _score_texts_finbert(texts)
    except Exception:
        logger.info("Using VADER fallback for sentiment scoring")
        return _score_texts_vader(texts)


# ---------------------------------------------------------------------------
# Public API — same signatures as Phase 5
# ---------------------------------------------------------------------------


def score_hansard_sentiment(
    results: list[HansardResult],
    topic: str,
) -> SentimentSignal:
    """Score the sentiment of Hansard debate titles mentioning a topic.

    Uses FinBERT (financial-text model) with VADER fallback.
    """
    if not results:
        return SentimentSignal(
            topic=topic,
            sample_size=0,
            mean_sentiment=0.0,
            sentiment_label="neutral",
            recent_trend="stable",
            summary=f"No debates found on '{topic}' to analyse sentiment.",
        )

    # Collect texts and dates
    texts = []
    dates = []
    for r in results:
        if r.title:
            texts.append(r.title)
            dates.append(r.date)

    if not texts:
        return SentimentSignal(
            topic=topic,
            sample_size=0,
            mean_sentiment=0.0,
            sentiment_label="neutral",
            recent_trend="stable",
            summary=f"No scoreable text found on '{topic}'.",
        )

    compound_scores = _score_texts(texts)
    scores = [{"date": d, "compound": c} for d, c in zip(dates, compound_scores)]

    mean_sent = sum(s["compound"] for s in scores) / len(scores)
    label = _sentiment_label(mean_sent)
    trend = _sentiment_trend(scores)

    summary = (
        f"Parliamentary tone on '{topic}' is predominantly {label} "
        f"(mean {mean_sent:+.2f} across {len(scores)} recent debates)"
        f"{', ' + trend + ' over the last 30 days' if trend != 'stable' else ''}."
    )

    return SentimentSignal(
        topic=topic,
        sample_size=len(scores),
        mean_sentiment=round(mean_sent, 3),
        sentiment_label=label,
        recent_trend=trend,
        summary=summary,
    )


def score_written_questions_sentiment(
    results: list[WrittenQuestion],
    topic: str,
) -> SentimentSignal:
    """Score the sentiment/hostility of Written Questions on a topic.

    Uses FinBERT (financial-text model) with VADER fallback.
    """
    if not results:
        return SentimentSignal(
            topic=topic,
            sample_size=0,
            mean_sentiment=0.0,
            sentiment_label="neutral",
            recent_trend="stable",
            summary=f"No written questions found on '{topic}' to analyse.",
        )

    texts = []
    dates = []
    for wq in results:
        if wq.question_text:
            texts.append(wq.question_text)
            dates.append(wq.date_tabled)

    if not texts:
        return SentimentSignal(
            topic=topic,
            sample_size=0,
            mean_sentiment=0.0,
            sentiment_label="neutral",
            recent_trend="stable",
            summary=f"No scoreable written questions found on '{topic}'.",
        )

    compound_scores = _score_texts(texts)
    scores = [{"date": d, "compound": c} for d, c in zip(dates, compound_scores)]

    mean_sent = sum(s["compound"] for s in scores) / len(scores)
    label = _sentiment_label(mean_sent)
    trend = _sentiment_trend(scores)

    summary = (
        f"Written Question tone on '{topic}' is {label} "
        f"(mean {mean_sent:+.2f} across {len(scores)} questions)"
        f"{', ' + trend + ' over the last 30 days' if trend != 'stable' else ''}."
    )

    return SentimentSignal(
        topic=topic,
        sample_size=len(scores),
        mean_sentiment=round(mean_sent, 3),
        sentiment_label=label,
        recent_trend=trend,
        summary=summary,
    )


def _sentiment_label(score: float) -> str:
    """Classify a compound score into a label."""
    if score >= 0.05:
        return "positive"
    elif score <= -0.05:
        return "negative"
    return "neutral"


def _sentiment_trend(
    scores: list[dict],
) -> str:
    """Compare sentiment of last 30 days vs prior 30 days."""
    now = datetime.now(timezone.utc)
    cutoff = now - timedelta(days=30)

    recent = []
    older = []
    for s in scores:
        if not s["date"]:
            continue
        try:
            d = datetime.strptime(s["date"], "%Y-%m-%d").replace(tzinfo=timezone.utc)
        except ValueError:
            continue
        if d >= cutoff:
            recent.append(s["compound"])
        else:
            older.append(s["compound"])

    if not recent or not older:
        return "stable"

    recent_mean = sum(recent) / len(recent)
    older_mean = sum(older) / len(older)
    diff = recent_mean - older_mean

    if diff > 0.1:
        return "improving"
    elif diff < -0.1:
        return "worsening"
    return "stable"
