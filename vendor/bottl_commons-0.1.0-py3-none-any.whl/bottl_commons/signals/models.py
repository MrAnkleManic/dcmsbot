"""Pydantic models for political signal outputs."""

from __future__ import annotations

from pydantic import BaseModel


class TopicSalience(BaseModel):
    """Parliamentary salience time series for a topic.

    Tracks how many debates mention a topic per time bucket,
    producing a forecastable time series for TimesFM.
    """

    topic: str
    dates: list[str]  # ISO date strings for each bucket start
    values: list[float]  # debate count per bucket (float for TimesFM)
    total_mentions: int
    trend: str  # "rising", "falling", or "stable"
    change_pct: float  # percentage change: last period vs prior
    change_description: str  # human-readable trend summary


class SentimentSignal(BaseModel):
    """Sentiment analysis result for parliamentary text on a topic."""

    topic: str
    sample_size: int
    mean_sentiment: float  # -1 to +1
    sentiment_label: str  # "positive", "negative", "neutral"
    recent_trend: str  # "improving", "worsening", "stable"
    summary: str  # human-readable summary


class StanceSignal(BaseModel):
    """DeBERTa stance classification result for parliamentary text.

    Unlike SentimentSignal (which measures emotional valence), this
    measures whether speeches are supportive, critical, or neutral
    *toward a specific topic*. Parliamentary formal register reads
    as neutral sentiment but can have clear stance.
    """

    topic: str
    sample_size: int
    supportive: int  # count of supportive speeches
    critical: int  # count of critical speeches
    neutral: int  # count of neutral speeches
    dominant_stance: str  # "supportive", "critical", or "neutral"
    recent_trend: str  # "increasingly critical", "increasingly supportive", "stable"
    summary: str  # human-readable summary


class TopicInfo(BaseModel):
    """A single topic cluster discovered by BERTopic."""

    id: int
    label: str  # e.g. "energy prices, gas bills, fuel poverty"
    keywords: list[str]  # top keywords for this topic
    count: int  # number of debates in this topic
    representative_debates: list[str]  # debate titles
    trend: str  # "growing", "stable", "declining"


class TopicAnalysis(BaseModel):
    """BERTopic analysis result over retrieved Hansard debates."""

    topics: list[TopicInfo]
    total_documents: int
    model_info: str = "BERTopic + all-MiniLM-L6-v2"
